{{- define "arlasServices.labels" -}}
# app.kubernetes.io/part-of: arlas-stack
# app.kubernetes.io/managed-by: {{ .Release.Service }}
# app.kubernetes.io/instance: {{ .Release.Name }}
# app.kubernetes.io/version: {{ .Chart.AppVersion }}
# app.kubernetes.io/name: arlas-stack
{{- end }}


{{- define "arlasServices.loggingEnv" -}}
# LOGGING
- name: ARLAS_LOGGING_LEVEL
  value: {{ .Values.logger.loggingLevel }}
- name: ARLAS_LOGGING_CONSOLE_LEVEL
  value: {{ .Values.logger.loggingConsoleLevel }}
- name: ARLAS_LOGGING_FILE_LEVEL
  value: "OFF"
- name: ARLAS_LOGGING_FILE
  value: {{ .Values.logger.loggingFile | quote }}
{{- end }}

{{- define "arlasServices.cacheEnv" -}}
# CACHE CONFIG
- name: ARLAS_CACHE_TIMEOUT
  value: {{ .Values.cacheTimeout | quote }}
- name: ARLAS_CACHE_FACTORY_CLASS
  value: {{ .Values.cacheFactoryClass | quote }}
{{- end }}


{{- define "arlasServices.elasticEnv" -}}
# ELASTICSEARCH CONFIGURATION
- name: ARLAS_ELASTIC_INDEX
  value: .arlas
- name: ARLAS_ELASTIC_CLUSTER
  value: {{ .Values.elastic.cluster| quote }}
- name: ARLAS_ELASTIC_NODES
  value: {{ .Values.elastic.nodes| quote  }}
- name: ARLAS_APP_ELASTIC_LOGIN
  valueFrom:
    secretKeyRef:
      name: {{ .Values.elastic.existingSecret | default "arlas-stack-secret" }}
      key: {{ .Values.elastic.loginKey | default "ARLAS_APP_ELASTIC_LOGIN" }}
- name: ARLAS_APP_ELASTIC_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ .Values.elastic.existingSecret | default "arlas-stack-secret" }}
      key: {{ .Values.elastic.passwordKey | default "ARLAS_APP_ELASTIC_PASSWORD" }}
- name: ARLAS_ELASTIC_CREDENTIALS
  value: "$(ARLAS_APP_ELASTIC_LOGIN):$(ARLAS_APP_ELASTIC_PASSWORD)"
- name: ARLAS_ELASTIC_SKIP_MASTER
  value: {{ .Values.elastic.skipMaster | quote }}
- name: ARLAS_ELASTIC_SNIFFING
  value: {{ .Values.elastic.sniffing | quote }}
- name: ARLAS_ELASTIC_ENABLE_SSL
  value: {{ .Values.elastic.ssl.enabled | quote }}
{{- end }}

{{- define "arlasServices.otel" -}}
# OTEL CONFIGURATION
- name: OTEL_EXPORTER_OTLP_ENDPOINT
  value: {{ .Values.otel.endpoint | quote }}
- name: OTEL_EXPORTER_OTLP_PROTOCOL
  value: {{ .Values.otel.protocol | quote }}
- name: OTEL_RESOURCE_ATTRIBUTES
  value: {{ tpl .Values.otel.attributes . | quote }}
- name: OTEL_INSTRUMENTATION_HTTP_SERVER_REQUEST_IGNORED_USERAGENTS
  value: {{ .Values.otel.ignoredUserAgents | quote }}
{{- if .Values.otel.auth.enabled }}
- name: OTEL_TOKEN
  valueFrom:
    secretKeyRef:
      name: {{ .Values.otel.auth.secretName }}
      key: {{ .Values.otel.auth.secretKey }}
- name: OTEL_EXPORTER_OTLP_HEADERS
  value: "Authorization=Bearer $(OTEL_TOKEN)"
{{- end }}
{{- range $k, $v := .Values.otel.extraEnv }}
- name: {{ $k }}
  value: {{ $v | quote }}
{{- end }}
{{- end }}

{{- define "arlasServices.keycloakEnv" -}}
{{- if .Values.keycloak.enabled }}
  # -- ARLAS Policy Enforcer
  # -- Policy Enforcer class to use among `io.arlas.filter.impl.NoPolicyEnforcer`, `io.arlas.filter.impl.HTTPPolicyEnforcer`, `io.arlas.filter.impl.KeycloakPolicyEnforcer`
- name: ARLAS_AUTH_POLICY_CLASS
  value: io.arlas.filter.impl.KeycloakPolicyEnforcer
#  value: io.arlas.filter.impl.HTTPPolicyEnforcer
#  value: io.arlas.filter.impl.NoPolicyEnforcer
- name: ARLAS_AUTH_KEYCLOAK_REALM
  value: {{ .Values.keycloak.realm | quote }}
- name: ARLAS_AUTH_KEYCLOAK_RESOURCE
  value: {{ .Values.keycloak.client | quote }}
- name: ARLAS_AUTH_KEYCLOAK_SECRET
  valueFrom:
    secretKeyRef:
      name: {{ .Values.keycloak.existingSecret | default "arlas-stack-secret" }}
      key: {{ .Values.keycloak.secretKey | default "ARLAS_APP_KEYCLOAK_SECRET" }}
- name: ARLAS_AUTH_KEYCLOAK_URL
  value: {{ .Values.keycloak.url | quote }}
- name: ARLAS_CHECK_ORGANISATIONS
  value: "false"
{{- end }}
{{- end }}  

{{- define "arlasServices.corsEnv" -}}
- name: ARLAS_CORS_ENABLED
  value: {{ .Values.cors.enabled | quote }}
- name: ARLAS_CORS_ALLOWED_ORIGINS
  value: {{ .Values.cors.allowedOrigins | squote }}
- name: ARLAS_CORS_ALLOWED_HEADERS
  value: {{ .Values.cors.allowedHeaders | quote }}
- name: ARLAS_CORS_ALLOWED_METHODS
  value: {{ .Values.cors.allowedMethods | quote }}
- name: ARLAS_CORS_ALLOWED_CREDENTIALS
  value: {{ .Values.cors.allowedCredentials | quote }}
- name: ARLAS_CORS_EXPOSED_HEADERS
  value: {{ .Values.cors.exposedHeaders | quote }}
{{- end }}


{{- define "arlasServices.mountCertificate" -}}
{{- if .Values.services.mountCertificate }}
            - name: arlas-certificate-configmap
              mountPath: /opt/app/store/
              readOnly: true
{{- end }}
{{- end }}

{{- define "arlasServices.volumeCertificate" -}}
{{- if .Values.services.mountCertificate }}
        - name: arlas-certificate-configmap
          configMap:
            name: arlas-certificate-configmap
{{- end }}
{{- end }}
